# Configuration for the cli

cli_configuration = {
    "server_url": "https://ad-build-dev.slac.stanford.edu/api/cbs/v1/"
}
# "server_url": "https://accel-webapp-dev.slac.stanford.edu/api/cbs/v1/"

INPUT_PREFIX = "[?] "