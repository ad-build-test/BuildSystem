# BuildSystem Command Line Interface
## Desc
0. Assuming you have the /dist, install package with ```pip install ADBS_CLI_PNISPERO_1.x.x```
1. Run with ```bs```
2. ex: ```bs run build```

## Dev
1. To rebuild package, just do a ```python -m build```
